<?php
/**
 * Created by PhpStorm.
 * User: Mike
 * Date: 1/1/2017
 * Time: 9:22 PM
 */

return [
	'id'          => '',
	'class'       => '',
	'style'       => '',
	'heading'     => '',
	'image'       => '',
	'image_thumb' => '',
	'image_alt'   => '',
	'link_href'   => '',
	'link_title'  => '',
	'link_class'  => '',
	'new_window'  => false,
];